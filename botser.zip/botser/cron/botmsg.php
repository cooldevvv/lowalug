<?php

		$tlg->sendMessage ([
			'chat_id' => CHAT_ID_NOTIFICACAO,
	'text' => "VEM EM MIM BB, PROMOÇAO",
			'parse_mode' => 'html'
		]);

